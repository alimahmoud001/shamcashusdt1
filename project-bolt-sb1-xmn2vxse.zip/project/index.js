require('dotenv').config();
require('./src/bot');